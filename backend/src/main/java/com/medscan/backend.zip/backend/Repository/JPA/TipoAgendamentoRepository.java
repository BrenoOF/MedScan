package com.medscan.backend.Repository.JPA;

import com.medscan.backend.Model.TipoAgendamento;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TipoAgendamentoRepository extends JpaRepository<TipoAgendamento, Long> {
}
