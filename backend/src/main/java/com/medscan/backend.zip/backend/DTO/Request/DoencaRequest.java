package com.medscan.backend.DTO.Request;

public record DoencaRequest(
        String cid,
        String nomeDoenca,
        String tipoAgravo,
        String tipoSexo
) {
}
