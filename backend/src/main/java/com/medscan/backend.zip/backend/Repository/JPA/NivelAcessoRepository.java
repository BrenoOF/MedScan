package com.medscan.backend.Repository.JPA;

import com.medscan.backend.Model.NivelAcesso;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NivelAcessoRepository extends JpaRepository<NivelAcesso, Long> {
}
