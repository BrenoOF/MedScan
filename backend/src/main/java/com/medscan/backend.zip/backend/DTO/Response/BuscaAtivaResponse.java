package com.medscan.backend.DTO.Response;

public record BuscaAtivaResponse(
    Long id,
    AgendamentoResponse agendamento,
    Boolean febre,
    Boolean tosse,
    Boolean dificuldadeRespirar,
    Boolean contatoConfirmadoCovid
){}
