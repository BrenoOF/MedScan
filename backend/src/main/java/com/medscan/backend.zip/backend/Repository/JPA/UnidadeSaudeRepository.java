package com.medscan.backend.Repository.JPA;

import com.medscan.backend.Model.UnidadeSaude;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UnidadeSaudeRepository extends JpaRepository<UnidadeSaude, Long> {
}
