package com.medscan.backend.DTO.Request;

public record NivelAcessoRequest(
        String descricao
) {
}
