package com.medscan.backend.DTO.Response;

import java.util.List;

public record TipoServicoResponse(
        Long id,
        UnidadeSaudeResponse unidadeSaude,
        TipoAgendamentoResponse tipoAgendamento,
        List<AgendamentoResponse> agendamentoList
) {
}
