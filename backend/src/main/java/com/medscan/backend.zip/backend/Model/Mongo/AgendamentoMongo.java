package com.medscan.backend.Model.Mongo;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.*;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Document(collection = "agendamentos")
public class AgendamentoMongo {

    @MongoId
    @Field("Id")
    private String id;

    @Field("agendamentoId")
    private Long idAgendamento;

    @Field("pacienteNome")
    private String pacienteNome;

    @Field("atendenteNome")
    private String atendenteNome;

    @Field("dataAgendamento")
    private LocalDate dataAgendamento;

    @Field("tipoAgendamento")
    private String tipoAgendamento;

    @Field("status")
    private String status;

    @Field("sintomas")
    private String sintomas;
}
