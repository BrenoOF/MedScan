package com.medscan.backend.Repository.JPA;

public interface FuncaoRepository {
}
