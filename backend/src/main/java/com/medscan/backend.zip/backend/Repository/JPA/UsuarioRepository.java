package com.medscan.backend.Repository.JPA;

import com.medscan.backend.Model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
    Usuario findUsuarioByEmailEqualsIgnoreCaseAndSenhaIgnoreCase(String email, String senha);
}
