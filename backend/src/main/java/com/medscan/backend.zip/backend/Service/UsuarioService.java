package com.medscan.backend.Service;

import com.medscan.backend.DTO.Request.UsuarioRequest;
import com.medscan.backend.DTO.Response.NivelAcessoResponse;
import com.medscan.backend.DTO.Response.UsuarioResponse;
import com.medscan.backend.Model.NivelAcesso;
import com.medscan.backend.Model.Usuario;
import com.medscan.backend.Repository.JPA.NivelAcessoRepository;
import com.medscan.backend.Repository.JPA.UsuarioRepository;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Getter
@Setter
public class UsuarioService {

    private final UsuarioRepository usuarioRepository;
    private final NivelAcessoRepository nivelAcessoRepository;



    private UsuarioResponse toResponse(Usuario usuario){
        return new UsuarioResponse(
                usuario.getId(),
                usuario.getNome(),
                usuario.getEmail(),
                usuario.getTelefone(),
                new NivelAcessoResponse(
                        usuario.getNivelAcesso().getId(), usuario.getNivelAcesso().getDescricao()
                )
        );
    }

    public UsuarioResponse buscarPorId(Long id){
        Usuario usuario = usuarioRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado"));
        return toResponse(usuario);
    }


    public UsuarioResponse criarUsuario(UsuarioRequest usuarioRequest) {
        Usuario usuario = new Usuario();
        if((usuarioRequest.nome() == null || usuarioRequest.nome().isEmpty()) || (usuarioRequest.email() == null || usuarioRequest.email().isEmpty()) || (usuarioRequest.senha() == null || usuarioRequest.senha().isEmpty())) {
            return toResponse(usuario);
        }
        usuario.setNome(usuarioRequest.nome());
        usuario.setEmail(usuarioRequest.email());
        if(usuarioRequest.telefone() == null){
            usuario.setTelefone("00+ (00)00000-0000");
        }else{
            usuario.setTelefone(usuarioRequest.telefone());
        }
        usuario.setSenha(usuarioRequest.senha());

        NivelAcesso nivel = new NivelAcesso();

        if(usuarioRequest.nivelAcessoId() != null){
            nivel = nivelAcessoRepository.findById(usuarioRequest.nivelAcessoId())
                    .orElseThrow(() -> new RuntimeException("Nivel de Acesso não encontrado"));
        }else{
            nivel.setId(1L);
            nivel.setDescricao("paciente");
        }

        usuario.setNivelAcesso(nivel);

        Usuario salvo = usuarioRepository.save(usuario);

        return toResponse(salvo);
    }

    public UsuarioResponse loginUsuario(UsuarioRequest usuarioRequest) {

        Usuario usuario = usuarioRepository.findUsuarioByEmailEqualsIgnoreCaseAndSenhaIgnoreCase(
                        usuarioRequest.email(),
                        usuarioRequest.senha()
                );

        if (usuario == null) {
            throw new RuntimeException("Usuário não encontrado ou credenciais inválidas");
        }

        return toResponse(usuario);
    }

}
