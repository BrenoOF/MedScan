package com.medscan.backend.Model;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Table(
        name = "agendamento",
        indexes = {
                @Index(name = "idx_tipoServico", columnList = "tiposervicoid"),
                @Index(name = "idx_diaAgendamento", columnList = "diaAgendamento"),
                @Index(name = "idx_status", columnList = "status"),
                @Index(name = "idx_pacienteid", columnList = "pacienteid")
        }
)
public class Agendamento {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "pacienteid", nullable = false)
    private Paciente paciente;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "atendenteid", nullable = false)
    private Atendente atendente;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "tiposervicoid")
    private TipoServico tipoServico;

    @Temporal(TemporalType.DATE)
    @Column(name = "diaCadastro", nullable = false)
    private LocalDate diaCadastro;

    @Temporal(TemporalType.TIME)
    @Column(name = "horaCadastro", nullable = false)
    private LocalTime horaCadastro;

    @Temporal(TemporalType.DATE)
    @Column(name = "diaAgendamento", nullable = false)
    private LocalDate diaAgendamento;

    @Temporal(TemporalType.TIME)
    @Column(name = "horaAgendamento", nullable = false)
    private LocalTime horaAgendamento;

    @Column(name = "escalador", nullable = false, length = 2)
    private Integer escalaDor;

    @Column(name = "sintomas", nullable = false, columnDefinition = "TEXT")
    private String sintomas;

    @Enumerated(EnumType.STRING)
    @Column(name = "classificacaorisco", nullable = false, columnDefinition = "ENUM('Não Urgente', 'Pouco Urgente', 'Urgente', 'Muito Urgente', 'Emergência')")
    private ClassificacaoRisco classificacaoRisco;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "doencaid", nullable = false)
    private Doenca doenca;

    @OneToOne(mappedBy = "agendamento", cascade = CascadeType.ALL)
    @ToString.Exclude
    private BuscaAtiva buscaAtiva;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, columnDefinition = "ENUM('Pendente', 'Agendado', 'Rejeitado')")
    private Status status;

    public enum Status {
        PENDENTE("Pendente"),
        AGENDADO("Agendado"),
        REJEITADO("Rejeitado");

        Status(String s) {
        }
    }

    public enum ClassificacaoRisco {
        NAO_URGENTE("Não Urgente"),
        POUCO_URGENTE("Pouco Urgente"),
        URGENTE("Urgente"),
        MUITO_URGENTE("Muito Urgente"),
        EMERGENCIA("Emergência");

        ClassificacaoRisco(String s) {
        }
    }
}