package com.medscan.backend.Repository.JPA;

import com.medscan.backend.Model.TipoServico;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TipoServicoRepository extends JpaRepository<TipoServico, Long> {
}
