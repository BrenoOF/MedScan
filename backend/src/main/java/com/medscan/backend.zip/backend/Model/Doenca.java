package com.medscan.backend.Model;

import jakarta.persistence.*;
import lombok.*;

import java.util.ArrayList;
import java.util.List;

@Entity
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Table(
        name = "doencas",
        indexes = {
                @Index(name = "idx_cid", columnList = "cid")
        })
public class Doenca {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @OneToMany(mappedBy = "doenca", cascade = CascadeType.ALL)
    @ToString.Exclude
    private List<Agendamento> agendamentoList = new ArrayList<>();

    @Column(name = "cid", nullable = false)
    private String cid;

    @Column(name = "nomedoenca", nullable = false)
    private String nomeDoenca;

    @Column(name = "tipoagravo", nullable = false)
    private String tipoAgravo;

    @Column(name = "tiposexo", nullable = false)
    private String tipoSexo;
}