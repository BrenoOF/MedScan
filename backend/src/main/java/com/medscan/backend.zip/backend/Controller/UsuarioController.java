package com.medscan.backend.Controller;

import com.medscan.backend.DTO.Request.UsuarioRequest;
import com.medscan.backend.DTO.Response.UsuarioResponse;
import com.medscan.backend.Service.UsuarioService;
import jakarta.servlet.http.HttpSession;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.Map;

@Controller
@RequestMapping("/usuario")
public class UsuarioController {

    private final UsuarioService usuarioService;

    public UsuarioController(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    @PostMapping("/usuarioNew")
    public ResponseEntity<UsuarioResponse> criarUsuario(@RequestBody UsuarioRequest request) {
        UsuarioResponse response = usuarioService.criarUsuario(request);
        if(response == null) {
            return ResponseEntity.status(401).body(null);
        }
        return ResponseEntity.ok(response);
    }

    @PostMapping("/usuarioLogin")
    public ResponseEntity<?> loginUsuario(@RequestBody UsuarioRequest request, HttpSession session) {
        try {
            if (session.getAttribute("usuarioLogado") != null) {
                session.removeAttribute("usuarioLogado");
            }
            UsuarioResponse response = usuarioService.loginUsuario(request);
            session.setAttribute("usuarioLogado", response);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            return ResponseEntity.status(401).body(Map.of("message", e.getMessage()));
        }
    }


}
