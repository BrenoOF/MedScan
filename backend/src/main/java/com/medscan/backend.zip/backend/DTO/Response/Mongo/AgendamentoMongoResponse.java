package com.medscan.backend.DTO.Response.Mongo;

import java.time.LocalDate;

public record AgendamentoMongoResponse(
        String id,
        Long idAgendamento,
        String pacienteNome,
        String atendenteNome,
        LocalDate dataAgendamento,
        String tipoAgendamento,
        String status,
        String sintomas
) {
}
