package com.medscan.backend.Repository.JPA;

import com.medscan.backend.Model.Paciente;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PacienteRepository extends JpaRepository<Paciente, Long> {
}
