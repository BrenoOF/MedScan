package com.medscan.backend.DTO.Response;

import java.util.List;

public record CategoriaNivelAcessoResponse(
        Long id,
        String descricao,
        List<Long> tipoNivelAcessoIds,
        List<Long> configNivelAcessoIds
) {}

