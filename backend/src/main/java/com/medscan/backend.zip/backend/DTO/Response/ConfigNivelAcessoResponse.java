package com.medscan.backend.DTO.Response;

public record ConfigNivelAcessoResponse(
        Long id,
        String descricao,
        NivelAcessoResponse nivelAcesso,
        Boolean status
) {
}
