package com.medscan.backend.Repository.JPA;

import com.medscan.backend.Model.Doenca;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DoencaRepository extends JpaRepository<Doenca, Long> {
}
