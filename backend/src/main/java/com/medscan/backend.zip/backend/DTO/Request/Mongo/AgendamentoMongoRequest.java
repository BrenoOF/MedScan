package com.medscan.backend.DTO.Request.Mongo;

import java.time.LocalDate;

public record AgendamentoMongoRequest(
        Long idAgendamento,
        String pacienteNome,
        String atendenteNome,
        LocalDate dataAgendamento,
        String tipoAgendamento,
        String status,
        String sintomas
) {
}
