package com.medscan.backend.DTO.Response;

public record TipoNivelAcessoResponse(
        Long id,
        Long nivelAcessoId,
        String nivelAcessoDescricao,
        Long categoriaNivelAcessoId,
        String categoriaNivelAcessoDescricao
) {}
