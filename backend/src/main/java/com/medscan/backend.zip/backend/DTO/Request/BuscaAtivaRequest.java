package com.medscan.backend.DTO.Request;

public record BuscaAtivaRequest(
        Long agendamentoId,
        Boolean febre,
        Boolean tosse,
        Boolean dificuldadeRespirar,
        Boolean contatoConfirmadoCovid
) {}
