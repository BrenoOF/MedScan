package com.medscan.backend.DTO.Response;

import java.util.List;

public record DoencaResponse(
        Long id,
        String cid,
        String nomeDoenca,
        String tipoAgravo,
        String tipoSexo,
        List<AgendamentoResponse> agendamentoList
) {
}
