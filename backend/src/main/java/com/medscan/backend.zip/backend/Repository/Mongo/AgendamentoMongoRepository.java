package com.medscan.backend.Repository.Mongo;

import com.medscan.backend.Model.Agendamento;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface AgendamentoMongoRepository extends MongoRepository<Agendamento, Long> {
}
