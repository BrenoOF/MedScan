package com.medscan.backend.Model;

import jakarta.persistence.*;
import lombok.*;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(
        name = "buscaativa",
        indexes = {
                @Index(name = "idx_agendamento", columnList = "agendamentoid")
        })
public class BuscaAtiva {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "agendamentoid", nullable = false, unique = true)
    private Agendamento agendamento;

    @Column(name = "febre", nullable = false)
    private Boolean febre;

    @Column(name = "tosse", nullable = false)
    private Boolean tosse;

    @Column(name = "dificuldaderespirar", nullable = false)
    private Boolean dificuldadeRespirar;

    @Column(name = "contatoconfirmadocovid", nullable = false)
    private Boolean contatoConfirmadoCovid;
}