package com.medscan.backend.DTO.Request;

public record UsuarioRequest(
        String nome,
        String email,
        String senha,
        String telefone,
        Long nivelAcessoId

) {
}
